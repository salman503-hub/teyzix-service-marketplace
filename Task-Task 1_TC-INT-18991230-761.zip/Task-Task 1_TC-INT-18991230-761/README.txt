TEYZIX CORE Internship Program
Task: Task 1
Reference ID: TC-INT-18991230-761

Project Description:
Multi-Vendor Service Marketplace Platform built with Django REST Framework (Backend) and React + Vite + Tailwind CSS (Frontend).
Includes user auth (JWT), provider profiles, service listings, requests feed, contract status timeline, rated reviews, and DM chat workspace.

How to Run Locally:
1. Backend Setup:
   cd backend
   python -m venv venv
   # Activate venv:
   # On Windows: .\venv\Scripts\activate
   # On macOS/Linux: source venv/bin/activate
   pip install -r requirements.txt
   python manage.py migrate
   python manage.py seed_db
   python manage.py runserver

2. Frontend Setup:
   cd frontend
   npm install
   npm run dev
